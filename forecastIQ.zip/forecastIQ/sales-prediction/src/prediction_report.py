import pandas as pd
import matplotlib.pyplot as plt
import joblib
from model_training import preprocess_data, load_data

def generate_prediction_report(actual_sales, predicted_sales):
    # Create a DataFrame for actual and predicted sales
    report_df = pd.DataFrame({
        'Actual Sales': actual_sales,
        'Predicted Sales': predicted_sales
    })

    # Calculate summary statistics
    summary_stats = report_df.describe()

    # Plot actual vs predicted sales
    plt.figure(figsize=(10, 5))
    plt.plot(report_df.index, report_df['Actual Sales'], label='Actual Sales', color='blue')
    plt.plot(report_df.index, report_df['Predicted Sales'], label='Predicted Sales', color='orange')
    plt.title('Actual vs Predicted Sales')
    plt.xlabel('Time')
    plt.ylabel('Sales')
    plt.legend()
    plt.grid()
    plt.savefig('sales_prediction_plot.png')
    plt.close()

    # Save the report to a CSV file
    report_df.to_csv('sales_prediction_report.csv', index=False)

    return summary_stats

if __name__ == "__main__":
    # Load the trained model
    model = joblib.load('sales_prediction_model.pkl')

    # Load and preprocess new data
    data = load_data('../data/local_store_sales.csv')
    features, target = preprocess_data(data)

    # Generate predictions
    predictions = model.predict(features)

    # Generate the prediction report
    summary_stats = generate_prediction_report(target, predictions)
    print(summary_stats)