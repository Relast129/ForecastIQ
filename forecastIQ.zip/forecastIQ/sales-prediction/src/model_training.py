import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import OneHotEncoder
import joblib

def load_data(file_path):
    data = pd.read_csv(file_path)
    return data

def preprocess_data(data):
    if 'date' in data.columns:
        # Convert 'date' column to datetime
        data['date'] = pd.to_datetime(data['date'])
        data['Year'] = data['date'].dt.year
        data['Month'] = data['date'].dt.month
        data.drop(['date'], axis=1, inplace=True)
    
    # Handle missing values
    data.ffill(inplace=True)
    
    # Convert categorical variables to numerical using OneHotEncoder
    categorical_columns = data.select_dtypes(include=['object']).columns
    if len(categorical_columns) > 0:
        encoder = OneHotEncoder(sparse=False, drop='first')
        encoded_categorical_data = encoder.fit_transform(data[categorical_columns])
        encoded_categorical_df = pd.DataFrame(encoded_categorical_data, columns=encoder.get_feature_names_out(categorical_columns))
        data = data.drop(categorical_columns, axis=1)
        data = pd.concat([data, encoded_categorical_df], axis=1)
    
    # Feature selection
    features = data.drop('sales', axis=1)
    target = data['sales']
    
    return features, target

def train_model(features, target):
    X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.2, random_state=42)
    
    # Hyperparameter tuning using GridSearchCV
    param_grid = {
        'n_estimators': [100, 200, 300],
        'max_depth': [None, 10, 20, 30],
        'min_samples_split': [2, 5, 10],
        'min_samples_leaf': [1, 2, 4]
    }
    
    rf = RandomForestRegressor(random_state=42)
    grid_search = GridSearchCV(estimator=rf, param_grid=param_grid, cv=5, n_jobs=-1, scoring='neg_mean_squared_error')
    grid_search.fit(X_train, y_train)
    
    best_model = grid_search.best_estimator_
    
    # Cross-validation
    cv_scores = cross_val_score(best_model, features, target, cv=5, scoring='neg_mean_squared_error')
    print(f'Cross-Validation Mean Squared Error: {-cv_scores.mean()}')
    
    best_model.fit(X_train, y_train)
    
    predictions = best_model.predict(X_test)
    mse = mean_squared_error(y_test, predictions)
    print(f'Mean Squared Error: {mse}')
    
    return best_model

def save_model(model, filename):
    joblib.dump(model, filename)

if __name__ == "__main__":
    data = load_data('../data/local_store_sales.csv')
    features, target = preprocess_data(data)
    model = train_model(features, target)
    save_model(model, 'sales_prediction_model.pkl')